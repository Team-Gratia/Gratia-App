import DownloadLogs from "./Download";
import React from "react";

const App = () => {
  return (
    <div>
      <DownloadLogs />
    </div>
  );
};

export default App;
