export { default as Main } from "./Main";
export { default as Loader } from "./Loader";
export { default as Card } from "./Card";
export { default as Rating } from "./Rating";
